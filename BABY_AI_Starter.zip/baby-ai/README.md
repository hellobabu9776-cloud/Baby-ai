# BABY AI — mobile-first starter

A small Android-friendly web/PWA prototype for the BABY AI personal assistant.

## Run it
- Open `index.html` in a modern browser for a basic preview.
- For installable PWA behavior and microphone access, host it on HTTPS (for example GitHub Pages) and open the site in Chrome on Android.
- In Chrome, use the browser menu and choose **Install app** or **Add to Home screen** if offered.

## Current features
- Responsive mobile-first interface
- Basic local demo replies (not a real AI model)
- Browser speech recognition when supported and permitted
- Quick action prompts
- PWA manifest and service worker

## Not included yet
- Real AI API/backend, secure key storage, accounts, cloud sync, persistent chat history, notifications, Gmail/calendar integrations, or a native APK.

Never put a private AI API key in frontend JavaScript. A secure backend is needed before connecting a real AI service.
